class Test {
  @Override
  public Bundle call(String method, String arg, Bundle extras) {
    pass;
  }
}