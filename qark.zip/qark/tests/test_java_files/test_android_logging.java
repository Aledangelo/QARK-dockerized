class Test {
  public void Test() {
    Log.d("test");
    Log.v("test");
  }
  public void Test2() {
    d("test");
    v("test");
  }
}