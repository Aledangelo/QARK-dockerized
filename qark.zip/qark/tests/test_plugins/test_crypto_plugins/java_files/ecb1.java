class Example{
	public static void main(){
		Cipher.getInstance("AES/ECB/PKCS5Padding", "SunJCE");
	}
}
